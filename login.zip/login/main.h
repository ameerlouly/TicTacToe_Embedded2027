#ifndef MAIN_H
#define MAIN_H

#include "mainwindow.h"
#include "secdialog.h"
#include <QApplication>

extern MainWindow* LoginWindow;
extern SecDialog* GameWindow;

#endif // MAIN_H
